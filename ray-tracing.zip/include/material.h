/**@file	/home/josivanmedeiros/Codes/ray-tracing/include/material.h
 * @author	josivanmedeiros
 * @version	704
 * @date
 * 	Created:	25th Apr 2019
 * 	Last Update:	25th Apr 2019
 */

#ifndef _MATERIAL_H_
#define _MATERIAL_H_

class Material
{
private:
  //@TODO
public:
  //@TODO
};

#endif // _MATERIAL_H_
